import math
import time

time_miliseconds=int(input("Enter  miliseconds:"))
time2_miliseconds=int(input("Enter 2nd miliseconds:"))

print(f"Square root of {time_miliseconds} after {time2_miliseconds} miliseconds is {math.sqrt(time_miliseconds)}")