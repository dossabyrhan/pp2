size_mylist=input("Enter  mylist:")
mylist=list(map(int,size_mylist.split()))
print("all True mylist:",all(mylist))