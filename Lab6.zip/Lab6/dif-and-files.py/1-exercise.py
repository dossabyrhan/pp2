import os

path= r"/Users/bekzatshaiyrgozha/Documents"
all=list(os.listdir(path))
print(all)