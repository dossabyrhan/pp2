from time import sleep

second = int(input())
sleep(second)
print("Ұйықтай ғой түйем")