import os

print(os.listdir())

path_to_folder="../examples/"
print(path_to_folder)